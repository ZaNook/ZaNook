<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_connect_db1 = "localhost";
$database_connect_db1 = "db1";
$username_connect_db1 = "root";
$password_connect_db1 = "root";
$connect_db1 = mysql_pconnect($hostname_connect_db1, $username_connect_db1, $password_connect_db1) or trigger_error(mysql_error(),E_USER_ERROR); 
?>